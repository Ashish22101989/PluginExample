## Script saved as AddCrmSdk.ps1
function LoadAssemblyFromToolsFolder($AssemblyName, $ToolSource)
{  
    $path = "D:\SDK\CoreTools";
    $path = Join-Path -Path "$path" -ChildPath "$AssemblyName"
    Write-Host "Adding assembly at: $path.";
    Add-Type -Path "$path";
}
 
if($sdkLoaded -eq $null) {
 
    LoadAssemblyFromToolsFolder -AssemblyName "Microsoft.Xrm.Sdk.dll" -ToolSource "CoreTools"
    LoadAssemblyFromToolsFolder -AssemblyName "Microsoft.Xrm.Tooling.Connector.dll" -ToolSource "CoreTools"
    LoadAssemblyFromToolsFolder -AssemblyName "Microsoft.Crm.Sdk.Proxy.dll" -ToolSource "CoreTools"
    LoadAssemblyFromToolsFolder -AssemblyName "Microsoft.Xrm.Sdk.Deployment.dll" -ToolSource "CoreTools"
 
    $sdkLoaded = $true
}