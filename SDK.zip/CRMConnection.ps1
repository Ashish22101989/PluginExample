param(
    [Parameter(Mandatory=$true)]
    [string] $ConnectionString
)
 
# Load the assemblies
D:\SDK\AddCrmSdk.ps1;
 
# Reuse existing connection if it is valid
if($crmService -ne $null -and $crmService.IsReady)
{
    Write-Host "Reusing existing service"
    return $crmService;
}
 
Write-Host "Getting service"
 
# Dynamics 365 requires TLS 1.2
Write-Host "Current Security Protocol: $([Net.ServicePointManager]::SecurityProtocol)";
if(-not [Net.ServicePointManager]::SecurityProtocol.HasFlag([Net.SecurityProtocolType]::Tls12)) 
{
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 'tls12';
 
    Write-Host "Updated Security Protocol: $([Net.ServicePointManager]::SecurityProtocol)";
}
#$ConnectionString = "AuthType=ClientSecret;url=https://orgf86c4a8e.crm8.dynamics.com;ClientId=fa633876-9a9d-48e9-aba8-0e30e828bbb7;ClientSecret=O9CghxySD2~-X~JbPhJZ0220oYLfT5Kr~d";
# Connection string normalization
if($ConnectionString -notlike "*;") 
{
    $ConnectionString += ";";
}
 
if($ConnectionString -notcontains "RequireNewInstance=True")
{
    $ConnectionString = "$ConnectionString RequireNewInstance=True;";
}
 
# Create service
$crmService= New-Object -TypeName Microsoft.Xrm.Tooling.Connector.CrmServiceClient -ArgumentList $ConnectionString;
 
if(-Not ($crmService.IsReady)) {
    Write-Host $crmService.LastCrmError;
 
    if($service.LastCrmException -ne $null) {
        Write-Error -Exception $crmService.LastCrmException;
    }
 
    Write-Host "Unable to create service connection to CRM."
    exit;
}
 
return $crmService;